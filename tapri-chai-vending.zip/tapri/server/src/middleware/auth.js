import jwt from 'jsonwebtoken';
import User from '../models/User.js';
import { HttpError } from '../utils/http.js';

export const signToken = (user) =>
  jwt.sign({ sub: user._id.toString() }, process.env.JWT_SECRET, { expiresIn: '7d' });

async function readUser(req) {
  const header = req.headers.authorization || '';
  if (!header.startsWith('Bearer ')) return null;
  try {
    const payload = jwt.verify(header.slice(7), process.env.JWT_SECRET);
    return await User.findById(payload.sub);
  } catch {
    return null;
  }
}

export async function optionalAuth(req, _res, next) {
  req.user = await readUser(req);
  next();
}

export async function requireAuth(req, _res, next) {
  req.user = await readUser(req);
  if (!req.user) return next(new HttpError(401, 'Sign in to see your orders.'));
  next();
}

export function requireAdmin(req, _res, next) {
  const key = process.env.ADMIN_KEY;
  if (!key || req.headers['x-admin-key'] !== key) {
    return next(new HttpError(403, 'Admin key missing or wrong.'));
  }
  next();
}
