export const SIZES = {
  small: { label: 'Small', ml: 90 },
  regular: { label: 'Regular', ml: 150 },
  large: { label: 'Large', ml: 250 },
};

export const SUGAR_LEVELS = ['No sugar', 'Less sugar', 'Regular', 'Extra sweet'];

// prices are in INR
export const CHAIS = [
  {
    slug: 'masala',
    name: 'Masala chai',
    notes: 'Cardamom, ginger, clove and black pepper',
    color: '#C28A55',
    prices: { small: 10, regular: 15, large: 25 },
    stock: 40,
    brewSeconds: 12,
  },
  {
    slug: 'adrak',
    name: 'Adrak chai',
    notes: 'Fresh ginger, sharp and warming',
    color: '#C99A62',
    prices: { small: 10, regular: 15, large: 25 },
    stock: 40,
    brewSeconds: 11,
  },
  {
    slug: 'elaichi',
    name: 'Elaichi chai',
    notes: 'Green cardamom, soft and sweet',
    color: '#D4A86E',
    prices: { small: 10, regular: 16, large: 26 },
    stock: 40,
    brewSeconds: 11,
  },
  {
    slug: 'kadak',
    name: 'Kadak chai',
    notes: 'Extra-steeped Assam, tea-stall strong',
    color: '#A8693A',
    prices: { small: 10, regular: 15, large: 24 },
    stock: 40,
    brewSeconds: 12,
  },
  {
    slug: 'kesar',
    name: 'Kesar chai',
    notes: 'Saffron strands in full-cream milk',
    color: '#DDA94A',
    prices: { small: 18, regular: 28, large: 42 },
    stock: 25,
    brewSeconds: 13,
  },
  {
    slug: 'irani',
    name: 'Irani chai',
    notes: 'Reduced milk, Hyderabad café style',
    color: '#B9763F',
    prices: { small: 14, regular: 22, large: 34 },
    stock: 25,
    brewSeconds: 13,
  },
];
