import 'dotenv/config';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
import express from 'express';
import helmet from 'helmet';
import cors from 'cors';
import morgan from 'morgan';
import rateLimit from 'express-rate-limit';

import { connectDB } from './config/db.js';
import { seedIfEmpty } from './seed.js';
import authRoutes from './routes/auth.js';
import productRoutes from './routes/products.js';
import orderRoutes from './routes/orders.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const isProd = process.env.NODE_ENV === 'production';

if (!process.env.JWT_SECRET) {
  if (isProd) throw new Error('JWT_SECRET must be set in production.');
  process.env.JWT_SECRET = 'dev-only-secret';
  console.warn('JWT_SECRET not set, using an insecure development secret.');
}

const app = express();
app.set('trust proxy', 1);
// The Vite bundle and Google Fonts need a custom CSP; add one for your own domain before going live.
app.use(helmet({ contentSecurityPolicy: false }));
app.use(
  cors({
    origin: (process.env.CLIENT_ORIGIN || 'http://localhost:5173').split(',').map((s) => s.trim()),
  })
);
app.use(express.json({ limit: '10kb' }));
if (!isProd) app.use(morgan('dev'));

const limiter = (max) => rateLimit({ windowMs: 60_000, max, standardHeaders: true, legacyHeaders: false });

app.get('/api/health', (_req, res) => res.json({ ok: true }));
app.use('/api/auth', limiter(20), authRoutes);
app.use('/api/products', productRoutes);
app.use('/api/orders', limiter(240), orderRoutes);
app.use('/api', (_req, res) => res.status(404).json({ message: 'Not found.' }));

// In production the same server also serves the built React app.
const dist = path.resolve(__dirname, '../../client/dist');
if (isProd && fs.existsSync(dist)) {
  app.use(express.static(dist));
  app.get('*', (_req, res) => res.sendFile(path.join(dist, 'index.html')));
}

// eslint-disable-next-line no-unused-vars
app.use((err, _req, res, _next) => {
  if (err.name === 'ValidationError') return res.status(400).json({ message: err.message });
  const status = err.status || 500;
  if (status === 500) console.error(err);
  res.status(status).json({ message: status === 500 ? 'Server error. Try again.' : err.message, ...(err.extra || {}) });
});

const port = process.env.PORT || 5000;
await connectDB(process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/tapri');
await seedIfEmpty();
app.listen(port, () => console.log(`Tapri API listening on http://localhost:${port}`));
