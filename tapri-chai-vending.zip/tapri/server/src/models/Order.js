import mongoose from 'mongoose';

const orderSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null, index: true },
    customerName: { type: String, default: '', maxlength: 24 },
    product: { type: mongoose.Schema.Types.ObjectId, ref: 'Product', required: true },
    productName: { type: String, required: true },
    color: { type: String, required: true },
    size: { type: String, enum: ['small', 'regular', 'large'], required: true },
    sugar: { type: Number, min: 0, max: 3, default: 2 },
    price: { type: Number, required: true },
    token: { type: String, required: true },
    brewSeconds: { type: Number, required: true },
    readyAt: { type: Date, required: true },
    // "brewing" here means "not collected yet"; ready/brewing is derived from readyAt
    status: { type: String, enum: ['brewing', 'collected'], default: 'brewing' },
  },
  { timestamps: true }
);

export default mongoose.model('Order', orderSchema);
