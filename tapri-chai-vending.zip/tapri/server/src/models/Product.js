import mongoose from 'mongoose';

const price = { type: Number, required: true, min: 0 };

const productSchema = new mongoose.Schema(
  {
    slug: { type: String, required: true, unique: true, trim: true },
    name: { type: String, required: true, trim: true },
    notes: { type: String, default: '' },
    color: { type: String, default: '#C28A55' },
    prices: { small: price, regular: price, large: price },
    stock: { type: Number, default: 0, min: 0 },
    brewSeconds: { type: Number, default: 12, min: 5, max: 60 },
    active: { type: Boolean, default: true },
  },
  { timestamps: true }
);

productSchema.set('toJSON', {
  transform(_doc, ret) {
    ret.id = ret._id.toString();
    delete ret._id;
    delete ret.__v;
    return ret;
  },
});

export default mongoose.model('Product', productSchema);
