import mongoose from 'mongoose';

export async function connectDB(uri) {
  mongoose.set('strictQuery', true);
  try {
    await mongoose.connect(uri, { serverSelectionTimeoutMS: 5000 });
    console.log(`MongoDB connected: ${mongoose.connection.host}/${mongoose.connection.name}`);
  } catch (err) {
    console.error('\nCould not reach MongoDB at', uri);
    console.error('Start one with:  docker compose up mongo -d');
    console.error('or install MongoDB locally, or point MONGO_URI at MongoDB Atlas.\n');
    throw err;
  }
}
