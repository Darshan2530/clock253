import 'dotenv/config';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import mongoose from 'mongoose';
import { connectDB } from './config/db.js';
import Product from './models/Product.js';
import { CHAIS } from './data/chais.js';

export async function seedIfEmpty() {
  if ((await Product.countDocuments()) > 0) return false;
  await Product.insertMany(CHAIS);
  console.log(`Seeded ${CHAIS.length} chais.`);
  return true;
}

// `npm run seed` resets the menu and stock to the defaults.
const isMain = process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url);
if (isMain) {
  await connectDB(process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/tapri');
  await Product.deleteMany({});
  await Product.insertMany(CHAIS);
  console.log(`Menu reset: ${CHAIS.length} chais.`);
  await mongoose.disconnect();
}
