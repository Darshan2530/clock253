import { Router } from 'express';
import mongoose from 'mongoose';
import Product from '../models/Product.js';
import { SIZES, SUGAR_LEVELS } from '../data/chais.js';
import { requireAdmin } from '../middleware/auth.js';
import { HttpError, wrap } from '../utils/http.js';

const router = Router();

router.get(
  '/',
  wrap(async (_req, res) => {
    const products = await Product.find({ active: true }).sort({ createdAt: 1, name: 1 });
    res.json({ products, sizes: SIZES, sugarLevels: SUGAR_LEVELS });
  })
);

// Refill the machine: POST /api/products/:id/restock  { "amount": 20 }  + x-admin-key header
router.post(
  '/:id/restock',
  requireAdmin,
  wrap(async (req, res) => {
    const amount = Number(req.body.amount);
    if (!mongoose.isValidObjectId(req.params.id)) throw new HttpError(400, 'Invalid product id.');
    if (!Number.isInteger(amount) || amount < 1 || amount > 500) {
      throw new HttpError(400, 'amount must be a whole number from 1 to 500.');
    }
    const product = await Product.findByIdAndUpdate(req.params.id, { $inc: { stock: amount } }, { new: true });
    if (!product) throw new HttpError(404, 'Chai not found.');
    res.json(product);
  })
);

export default router;
