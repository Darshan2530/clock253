import { Router } from 'express';
import mongoose from 'mongoose';
import Order from '../models/Order.js';
import Product from '../models/Product.js';
import { SIZES } from '../data/chais.js';
import { optionalAuth, requireAuth } from '../middleware/auth.js';
import { HttpError, wrap } from '../utils/http.js';

const router = Router();

// An uncollected cup blocks the machine until a minute after it is ready.
const COLLECT_GRACE_MS = 60_000;

export function serializeOrder(o) {
  const now = Date.now();
  const readyMs = o.readyAt.getTime();
  const status = o.status === 'collected' ? 'collected' : now >= readyMs ? 'ready' : 'brewing';
  return {
    id: o._id.toString(),
    token: o.token,
    productId: o.product.toString(),
    productName: o.productName,
    color: o.color,
    size: o.size,
    sugar: o.sugar,
    price: o.price,
    brewSeconds: o.brewSeconds,
    status,
    createdAt: o.createdAt,
    readyAt: o.readyAt,
    serverTime: now, // lets the browser correct for clock differences
  };
}

const findActiveOrder = () =>
  Order.findOne({ status: 'brewing', readyAt: { $gt: new Date(Date.now() - COLLECT_GRACE_MS) } }).sort({ readyAt: -1 });

// Is the machine free right now?
router.get(
  '/machine',
  wrap(async (_req, res) => {
    const active = await findActiveOrder();
    res.json({
      busy: Boolean(active),
      freeInSeconds: active ? Math.max(0, Math.ceil((active.readyAt.getTime() - Date.now()) / 1000)) : 0,
    });
  })
);

router.get(
  '/mine',
  requireAuth,
  wrap(async (req, res) => {
    const orders = await Order.find({ user: req.user._id }).sort({ createdAt: -1 }).limit(20);
    res.json({ orders: orders.map(serializeOrder) });
  })
);

router.post(
  '/',
  optionalAuth,
  wrap(async (req, res) => {
    const { productId, size } = req.body;
    const sugar = Number(req.body.sugar ?? 2);
    const customerName = String(req.body.customerName || req.user?.name || '').trim().slice(0, 24);

    if (!mongoose.isValidObjectId(productId)) throw new HttpError(400, 'Pick a chai first.');
    if (!SIZES[size]) throw new HttpError(400, 'Pick a cup size.');
    if (!Number.isInteger(sugar) || sugar < 0 || sugar > 3) throw new HttpError(400, 'Pick a sugar level.');

    const active = await findActiveOrder();
    if (active) {
      const wait = Math.max(0, Math.ceil((active.readyAt.getTime() - Date.now()) / 1000));
      throw new HttpError(409, 'The machine is making another cup. Try again shortly.', { freeInSeconds: wait });
    }

    // Atomic: only decrement when there is stock left, so two people can't take the last cup.
    const product = await Product.findOneAndUpdate(
      { _id: productId, active: true, stock: { $gt: 0 } },
      { $inc: { stock: -1 } },
      { new: true }
    );
    if (!product) {
      const exists = await Product.exists({ _id: productId, active: true });
      throw new HttpError(exists ? 409 : 404, exists ? 'That chai is sold out.' : 'That chai is not on the menu.');
    }

    try {
      const order = await Order.create({
        user: req.user?._id ?? null,
        customerName,
        product: product._id,
        productName: product.name,
        color: product.color,
        size,
        sugar,
        price: product.prices[size],
        token: `T-${Math.floor(1000 + Math.random() * 9000)}`,
        brewSeconds: product.brewSeconds,
        readyAt: new Date(Date.now() + product.brewSeconds * 1000),
      });
      res.status(201).json(serializeOrder(order));
    } catch (err) {
      await Product.updateOne({ _id: product._id }, { $inc: { stock: 1 } }); // give the cup back
      throw err;
    }
  })
);

router.get(
  '/:id',
  wrap(async (req, res) => {
    if (!mongoose.isValidObjectId(req.params.id)) throw new HttpError(404, 'Order not found.');
    const order = await Order.findById(req.params.id);
    if (!order) throw new HttpError(404, 'Order not found.');
    res.json(serializeOrder(order));
  })
);

router.patch(
  '/:id/collect',
  optionalAuth,
  wrap(async (req, res) => {
    if (!mongoose.isValidObjectId(req.params.id)) throw new HttpError(404, 'Order not found.');
    const order = await Order.findById(req.params.id);
    if (!order) throw new HttpError(404, 'Order not found.');
    if (order.user && String(order.user) !== String(req.user?._id)) {
      throw new HttpError(403, 'This cup belongs to another account.');
    }
    if (Date.now() < order.readyAt.getTime()) throw new HttpError(409, 'Your chai is still brewing.');
    order.status = 'collected';
    await order.save();
    res.json(serializeOrder(order));
  })
);

export default router;
