# Tapri: chai vending machine (MERN + 3D)

Order a chai on the right, watch the machine pour it on the left. The machine is a live 3D scene
(React Three Fiber) modelled on your reference video: matte black body, copper trim, glowing amber
LED edges, touchscreen, grated drip tray, glass tumbler and swirling steam on a marble counter.

| Layer | Tech |
| --- | --- |
| Database | MongoDB + Mongoose (Product, Order, User) |
| API | Node 18+, Express, JWT auth, helmet, rate limiting |
| Frontend | React 18, Vite, three.js via @react-three/fiber + drei |

## Run it

You need Node 18+ and a MongoDB (Docker is the quickest).

```bash
npm run install:all          # installs root, server and client dependencies
docker compose up mongo -d   # MongoDB on localhost:27017 (skip if you have your own)
npm run dev                  # API on :5000, website on http://localhost:5173
```

The menu seeds itself on first start. `npm run seed` resets the menu and stock.
Server settings live in `server/.env` (copy of `server/.env.example`). Change `JWT_SECRET` before deploying.

### One-container production run

```bash
docker compose up --build    # MongoDB + app on http://localhost:5000
```

or without Docker: `npm run build` then `NODE_ENV=production npm start` (Express serves `client/dist`).

## How an order works

1. `POST /api/orders` checks the machine is free, atomically takes one cup from stock, and returns
   `readyAt` plus the server's clock (`serverTime`).
2. The browser derives progress from those timestamps, so the 3D pour, the touchscreen and the progress
   bar always agree, and a page refresh resumes the same cup.
3. At `readyAt` the screen shows the pickup code. **Take your chai** calls `PATCH /api/orders/:id/collect`
   and the cup lifts out of the machine.

Pour timing: heating 0 to 12%, pouring 12 to 92% (the liquid level and stream follow it), finishing after.

## API

| Method | Path | Notes |
| --- | --- | --- |
| GET | `/api/products` | menu, stock, sizes, sugar levels |
| POST | `/api/products/:id/restock` | `{ "amount": 20 }` with header `x-admin-key: $ADMIN_KEY` |
| POST | `/api/auth/register`, `/api/auth/login` | returns `{ token, user }` |
| GET | `/api/auth/me` | Bearer token |
| POST | `/api/orders` | `{ productId, size, sugar, customerName? }`; guests allowed |
| GET | `/api/orders/machine` | `{ busy, freeInSeconds }` |
| GET | `/api/orders/:id` | status is `brewing`, `ready` or `collected` |
| PATCH | `/api/orders/:id/collect` | only after `readyAt` |
| GET | `/api/orders/mine` | signed-in user's last 20 orders |

## Where to change things

- `server/src/data/chais.js`: chais, prices (INR), stock, brew time, liquid colour.
- `client/src/scene/Machine.jsx`: the machine. Colours, sizes and positions are constants at the top and inline.
- `client/src/scene/Steam.jsx`: steam density, swirl and speed.
- `client/src/scene/Scene.jsx`: lights, camera views (`VIEWS`), café backdrop.
- `client/src/styles.css`: colour tokens are at the top.

To use a modelled machine instead of the built-in one, export a `.glb` to `client/public/`, load it with
drei's `useGLTF` in `Machine.jsx`, and keep the `cup`, `liquid`, `stream` and `light` refs so the
animation still drives them.

## Known limits (worth knowing before you ship)

- Checkout is a demo. No payment is taken; add Razorpay/Stripe/UPI in `POST /api/orders` before real use.
- The "machine is busy" check is not a hard lock: two requests in the same millisecond could both pass.
  For a real machine, use a single-document lock or a queue.
- There is one virtual machine. Add a `machine` field to Order if you want a fleet.
- Helmet's CSP is switched off in `server/src/index.js` because of Google Fonts and the Vite bundle.
  Add a CSP for your domain in production.
