const BASE = import.meta.env.VITE_API_URL || '/api';

// localStorage can throw (private mode, blocked cookies), so every access is guarded.
export const storage = {
  get(key) {
    try {
      return localStorage.getItem(key);
    } catch {
      return null;
    }
  },
  set(key, value) {
    try {
      localStorage.setItem(key, value);
    } catch {
      /* ignore */
    }
  },
  del(key) {
    try {
      localStorage.removeItem(key);
    } catch {
      /* ignore */
    }
  },
};

const TOKEN_KEY = 'tapri:token';
let token = storage.get(TOKEN_KEY);

export const getToken = () => token;
export function setToken(value) {
  token = value;
  if (value) storage.set(TOKEN_KEY, value);
  else storage.del(TOKEN_KEY);
}

async function request(path, { method = 'GET', body } = {}) {
  let res;
  try {
    res = await fetch(BASE + path, {
      method,
      headers: {
        'Content-Type': 'application/json',
        ...(token ? { Authorization: `Bearer ${token}` } : {}),
      },
      body: body ? JSON.stringify(body) : undefined,
    });
  } catch {
    throw new Error('Cannot reach the server. Check that the API is running.');
  }
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const err = new Error(data.message || 'Something went wrong. Try again.');
    err.status = res.status;
    err.data = data;
    throw err;
  }
  return data;
}

export const api = {
  products: () => request('/products'),
  register: (body) => request('/auth/register', { method: 'POST', body }),
  login: (body) => request('/auth/login', { method: 'POST', body }),
  me: () => request('/auth/me'),
  createOrder: (body) => request('/orders', { method: 'POST', body }),
  getOrder: (id) => request(`/orders/${id}`),
  collectOrder: (id) => request(`/orders/${id}/collect`, { method: 'PATCH' }),
  myOrders: () => request('/orders/mine'),
};
