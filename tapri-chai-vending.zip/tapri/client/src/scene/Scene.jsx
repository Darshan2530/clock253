import { Suspense, useEffect, useMemo, useRef } from 'react';
import { Canvas, useFrame, useThree } from '@react-three/fiber';
import { ContactShadows, Environment, Lightformer, OrbitControls } from '@react-three/drei';
import * as THREE from 'three';
import Machine from './Machine.jsx';
import { makeMarbleTexture, makeMenuTexture } from './textures.js';

const VIEWS = {
  overview: { pos: [4.8, 3.3, 8.6], target: [0, 1.5, 0] },
  closeup: { pos: [1.9, 1.7, 4.2], target: [0, 1.15, 0.25] },
};

/* Glides the camera between presets; any drag by the visitor cancels the glide. */
function CameraRig({ view, viewKey }) {
  const { camera, controls } = useThree();
  const tween = useRef(null);

  useEffect(() => {
    if (!controls) return undefined;
    const stop = () => {
      tween.current = null;
    };
    controls.addEventListener('start', stop);
    return () => controls.removeEventListener('start', stop);
  }, [controls]);

  useEffect(() => {
    if (!controls) return;
    const v = VIEWS[view];
    tween.current = {
      t: 0,
      fromP: camera.position.clone(),
      fromT: controls.target.clone(),
      toP: new THREE.Vector3(...v.pos),
      toT: new THREE.Vector3(...v.target),
    };
  }, [view, viewKey, controls, camera]);

  useFrame((_, dt) => {
    const tw = tween.current;
    if (!tw || !controls) return;
    tw.t = Math.min(1, tw.t + dt / 1.6);
    const e = 1 - Math.pow(1 - tw.t, 3);
    camera.position.lerpVectors(tw.fromP, tw.toP, e);
    controls.target.lerpVectors(tw.fromT, tw.toT, e);
    controls.update();
    if (tw.t >= 1) tween.current = null;
  });

  return null;
}

function Counter() {
  const marble = useMemo(() => makeMarbleTexture(), []);
  return (
    <mesh position={[0, -0.15, 0.5]} receiveShadow>
      <boxGeometry args={[20, 0.3, 10]} />
      <meshPhysicalMaterial map={marble} roughness={0.22} clearcoat={0.5} clearcoatRoughness={0.25} />
    </mesh>
  );
}

function Cafe({ products }) {
  const menu = useMemo(() => makeMenuTexture(products), [products]);
  return (
    <group>
      <mesh position={[0, 4, -4.6]}>
        <planeGeometry args={[40, 14]} />
        <meshStandardMaterial color="#CBCDCE" roughness={0.9} />
      </mesh>
      <mesh position={[4.6, 3.1, -4.55]}>
        <planeGeometry args={[4.4, 2.4]} />
        <meshBasicMaterial map={menu} toneMapped={false} />
      </mesh>
      {/* out-of-focus pendant lights, like the café behind the machine in the video */}
      {[-7, -4.6, -2.4, 0.2, 2.4].map((x, i) => (
        <mesh key={x} position={[x, 4.6 - (i % 2) * 0.5, -4.2]}>
          <sphereGeometry args={[0.16, 16, 16]} />
          <meshBasicMaterial color="#FFC46B" toneMapped={false} />
        </mesh>
      ))}
    </group>
  );
}

export default function Scene({ products, phase, progress, color, size, name, token, view, viewKey }) {
  return (
    <Canvas
      shadows
      dpr={[1, 2]}
      camera={{ position: VIEWS.overview.pos, fov: 32, near: 0.1, far: 80 }}
      gl={{ antialias: true }}
      aria-label="3D chai vending machine. Drag to look around."
    >
      <color attach="background" args={['#D5D7D8']} />
      <fog attach="fog" args={['#D5D7D8', 16, 34]} />

      <Environment resolution={256} frames={1}>
        <Lightformer form="rect" intensity={2.2} position={[0, 6, 2]} scale={[12, 4, 1]} rotation-x={Math.PI / 2} />
        <Lightformer form="rect" intensity={1.2} color="#FFE2BC" position={[-6, 3, 4]} scale={[4, 5, 1]} rotation-y={Math.PI / 2.5} />
        <Lightformer form="rect" intensity={0.9} position={[6, 2, 3]} scale={[4, 4, 1]} rotation-y={-Math.PI / 2.5} />
        <Lightformer form="rect" intensity={0.6} position={[0, 3, -6]} scale={[14, 4, 1]} />
      </Environment>

      <ambientLight intensity={0.25} />
      <directionalLight
        castShadow
        position={[4, 7, 5]}
        intensity={1.6}
        shadow-mapSize={[2048, 2048]}
        shadow-camera-left={-5}
        shadow-camera-right={5}
        shadow-camera-top={6}
        shadow-camera-bottom={-3}
        shadow-bias={-0.0004}
      />

      <Suspense fallback={null}>
        <Counter />
        <Cafe products={products} />
        <Machine phase={phase} progress={progress} color={color} size={size} name={name} token={token} />
        <ContactShadows position={[0, 0.01, 0.2]} opacity={0.45} blur={2.6} far={4} scale={14} />
      </Suspense>

      <CameraRig view={view} viewKey={viewKey} />
      <OrbitControls
        makeDefault
        enablePan={false}
        enableDamping
        minDistance={3}
        maxDistance={13}
        minPolarAngle={0.5}
        maxPolarAngle={1.52}
        minAzimuthAngle={-1.1}
        maxAzimuthAngle={1.1}
        target={VIEWS.overview.target}
      />
    </Canvas>
  );
}
