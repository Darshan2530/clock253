import * as THREE from 'three';

const SANS = '"Instrument Sans", system-ui, sans-serif';

/* White marble counter, drawn once on a canvas. */
export function makeMarbleTexture() {
  const c = document.createElement('canvas');
  c.width = c.height = 1024;
  const g = c.getContext('2d');
  g.fillStyle = '#E9EAEB';
  g.fillRect(0, 0, 1024, 1024);

  let seed = 11;
  const rnd = () => (seed = (seed * 16807) % 2147483647) / 2147483647;

  for (let i = 0; i < 30; i++) {
    const x = rnd() * 1024;
    const y = rnd() * 1024;
    const r = 80 + rnd() * 220;
    const grad = g.createRadialGradient(x, y, 0, x, y, r);
    grad.addColorStop(0, `rgba(200,204,210,${0.1 + rnd() * 0.16})`);
    grad.addColorStop(1, 'rgba(200,204,210,0)');
    g.fillStyle = grad;
    g.fillRect(0, 0, 1024, 1024);
  }

  for (let i = 0; i < 16; i++) {
    let x = rnd() * 1024;
    let y = rnd() * 1024;
    g.beginPath();
    g.moveTo(x, y);
    for (let k = 0; k < 6; k++) {
      const nx = x + (rnd() - 0.3) * 260;
      const ny = y + (rnd() - 0.5) * 260;
      g.quadraticCurveTo(x + (rnd() - 0.5) * 140, y + (rnd() - 0.5) * 140, nx, ny);
      x = nx;
      y = ny;
    }
    g.strokeStyle = `rgba(108,114,126,${0.06 + rnd() * 0.16})`;
    g.lineWidth = 0.6 + rnd() * 2.2;
    g.stroke();
  }

  const t = new THREE.CanvasTexture(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.repeat.set(2.2, 1.4);
  t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 8;
  return t;
}

/* Soft puff used for every steam sprite. */
export function makeSteamTexture() {
  const c = document.createElement('canvas');
  c.width = c.height = 128;
  const g = c.getContext('2d');
  const blobs = [
    [64, 64, 56],
    [44, 56, 34],
    [82, 70, 36],
    [66, 40, 30],
  ];
  for (const [x, y, r] of blobs) {
    const grad = g.createRadialGradient(x, y, 0, x, y, r);
    grad.addColorStop(0, 'rgba(255,255,255,0.55)');
    grad.addColorStop(0.6, 'rgba(255,255,255,0.18)');
    grad.addColorStop(1, 'rgba(255,255,255,0)');
    g.fillStyle = grad;
    g.fillRect(0, 0, 128, 128);
  }
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

function leaf(g, cx, cy, w, h, rot, color) {
  g.save();
  g.translate(cx, cy);
  g.rotate(rot);
  g.beginPath();
  g.moveTo(0, h / 2);
  g.bezierCurveTo(w, h / 4, w, -h / 4, 0, -h / 2);
  g.bezierCurveTo(-w, -h / 4, -w, h / 4, 0, h / 2);
  g.fillStyle = color;
  g.fill();
  g.restore();
}

/* The machine's touchscreen. Redrawn whenever the order state changes. */
export function drawScreen(canvas, { phase, name, progress, token }) {
  const g = canvas.getContext('2d');
  const { width: W, height: H } = canvas;
  const bg = g.createLinearGradient(0, 0, W, H);
  bg.addColorStop(0, '#0B2A2B');
  bg.addColorStop(1, '#14403F');
  g.fillStyle = bg;
  g.fillRect(0, 0, W, H);
  g.textAlign = 'center';

  if (phase === 'idle') {
    leaf(g, W / 2 - 46, 108, 34, 96, -0.55, '#6FBF73');
    leaf(g, W / 2 + 46, 108, 34, 96, 0.55, '#8ED08A');
    leaf(g, W / 2, 98, 38, 112, 0, '#A9E3A0');
    g.fillStyle = '#F4EBDD';
    g.font = `600 46px ${SANS}`;
    g.fillText('Tapri chai', W / 2, 232);
    g.fillStyle = '#9FC7C0';
    g.font = `400 26px ${SANS}`;
    g.fillText('Choose a chai to begin', W / 2, 276);
    return;
  }

  if (phase === 'brewing') {
    const step = progress < 0.12 ? 'Heating milk and tea' : progress < 0.92 ? 'Pouring' : 'Finishing';
    g.fillStyle = '#F4EBDD';
    g.font = `600 40px ${SANS}`;
    g.fillText(name || 'Chai', W / 2, 110);
    g.fillStyle = '#9FC7C0';
    g.font = `400 28px ${SANS}`;
    g.fillText(step, W / 2, 160);
    g.fillStyle = 'rgba(255,255,255,0.14)';
    g.fillRect(56, 214, W - 112, 18);
    g.fillStyle = '#F2A24B';
    g.fillRect(56, 214, (W - 112) * Math.min(1, progress), 18);
    g.fillStyle = '#F4EBDD';
    g.font = `500 26px ${SANS}`;
    g.fillText(`${Math.round(progress * 100)}%`, W / 2, 278);
    return;
  }

  if (phase === 'ready') {
    g.fillStyle = '#F2A24B';
    g.font = `600 56px ${SANS}`;
    g.fillText('Ready', W / 2, 120);
    g.fillStyle = '#F4EBDD';
    g.font = `400 28px ${SANS}`;
    g.fillText('Pickup code', W / 2, 190);
    g.font = `600 64px ${SANS}`;
    g.fillText(token || '', W / 2, 262);
    return;
  }

  g.fillStyle = '#F4EBDD';
  g.font = `600 46px ${SANS}`;
  g.fillText('Enjoy your chai', W / 2, 170);
}

/* The menu board on the café wall behind the machine. */
export function makeMenuTexture(products) {
  const c = document.createElement('canvas');
  c.width = 1024;
  c.height = 560;
  const g = c.getContext('2d');
  g.fillStyle = '#1F1E1D';
  g.fillRect(0, 0, c.width, c.height);
  g.strokeStyle = '#B5703F';
  g.lineWidth = 6;
  g.strokeRect(14, 14, c.width - 28, c.height - 28);
  g.textAlign = 'left';
  g.fillStyle = '#F4EBDD';
  g.font = `700 52px ${SANS}`;
  g.fillText("Today's chai", 56, 98);
  g.font = `400 34px ${SANS}`;
  products.slice(0, 6).forEach((p, i) => {
    const y = 168 + i * 62;
    g.fillStyle = p.color;
    g.beginPath();
    g.arc(70, y - 11, 11, 0, Math.PI * 2);
    g.fill();
    g.fillStyle = '#E8DFD0';
    g.fillText(p.name, 100, y);
    g.textAlign = 'right';
    g.fillStyle = '#F2A24B';
    g.fillText(`₹${p.prices?.regular ?? ''}`, c.width - 56, y);
    g.textAlign = 'left';
  });
  const t = new THREE.CanvasTexture(c);
  t.colorSpace = THREE.SRGBColorSpace;
  t.anisotropy = 8;
  return t;
}
