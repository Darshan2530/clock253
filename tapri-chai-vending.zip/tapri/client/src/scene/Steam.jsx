import { useEffect, useMemo } from 'react';
import { useFrame } from '@react-three/fiber';
import * as THREE from 'three';
import { makeSteamTexture } from './textures.js';

const COUNT = 34;

/* Curling steam that swirls around the cup, like the smoke in the reference video. */
export default function Steam({ phase, progress, cupTop, x = 0, z = 0.28 }) {
  const { group, sprites, texture } = useMemo(() => {
    const texture = makeSteamTexture();
    const group = new THREE.Group();
    const sprites = [];
    for (let i = 0; i < COUNT; i++) {
      const mat = new THREE.SpriteMaterial({
        map: texture,
        color: '#F4E7D4',
        transparent: true,
        depthWrite: false,
        opacity: 0,
      });
      const sprite = new THREE.Sprite(mat);
      sprite.userData.noShadow = true;
      group.add(sprite);
      sprites.push(sprite);
    }
    return { group, sprites, texture };
  }, []);

  const level = useMemo(() => ({ current: 0 }), []);

  useEffect(
    () => () => {
      sprites.forEach((s) => s.material.dispose());
      texture.dispose();
    },
    [sprites, texture]
  );

  useFrame(({ clock }, dt) => {
    let target = 0;
    if (phase === 'brewing') target = 0.25 + 0.75 * Math.min(1, progress * 1.4);
    else if (phase === 'ready') target = 0.45;
    else if (phase === 'collecting') target = 0.2;
    level.current += (target - level.current) * Math.min(1, dt * 2.5);

    const time = clock.elapsedTime;
    for (let i = 0; i < COUNT; i++) {
      const s = sprites[i];
      const t = (time * 0.12 + i / COUNT) % 1;
      const dir = i % 2 ? 1 : -1;
      const angle = i * 2.4 + t * 5.5 * dir;
      const radius = 0.22 + t * 0.55 * (0.6 + ((i * 7) % 5) / 10);
      s.position.set(
        x + Math.cos(angle) * radius,
        cupTop - 0.2 + t * 0.95,
        z + Math.sin(angle) * radius * 0.7
      );
      const size = 0.35 + t * 0.85;
      s.scale.set(size, size, 1);
      s.material.rotation = angle * 0.5;
      s.material.opacity = Math.sin(Math.PI * t) * 0.42 * level.current;
      s.visible = s.material.opacity > 0.004;
    }
  });

  return <primitive object={group} />;
}
