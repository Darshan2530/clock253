import { useEffect, useMemo, useRef } from 'react';
import { useFrame } from '@react-three/fiber';
import { RoundedBox } from '@react-three/drei';
import * as THREE from 'three';
import Steam from './Steam.jsx';
import { drawScreen } from './textures.js';

export const SIZE_SCALE = { small: 0.88, regular: 1, large: 1.14 };

const W = 2.4; // machine width
const CUP_H = 0.8;
const CUP_Z = 0.28; // cup sits under the nozzle
const GRATE_Y = 0.33; // top of the drip-tray grate
const NOZZLE_Y = 1.7; // tip of the nozzle
const NOSHADOW = { noShadow: true };

const BODY = { color: '#1d1c1b', metalness: 0.55, roughness: 0.38 };
const clamp = (v, a, b) => Math.min(b, Math.max(a, v));

/**
 * The vending machine, built from primitives so the whole site works without any model download.
 * phase: 'idle' | 'brewing' | 'ready' | 'collecting'    progress: 0..1 while brewing
 */
export default function Machine({ phase, progress, color, size, name, token }) {
  const root = useRef();
  const cup = useRef();
  const liquid = useRef();
  const foam = useRef();
  const stream = useRef();
  const light = useRef();
  const dot = useRef();
  const cur = useRef({ fill: 0, scale: 1, stream: 0, off: new THREE.Vector3() });
  const target = useMemo(() => new THREE.Vector3(), []);

  const ledMat = useMemo(
    () => new THREE.MeshStandardMaterial({ color: '#FFE3B0', emissive: '#FFA23A', emissiveIntensity: 2.2, roughness: 0.4 }),
    []
  );
  const copperMat = useMemo(() => new THREE.MeshStandardMaterial({ color: '#B5703F', metalness: 1, roughness: 0.32 }), []);
  const screen = useMemo(() => {
    const canvas = document.createElement('canvas');
    canvas.width = 512;
    canvas.height = 320;
    const tex = new THREE.CanvasTexture(canvas);
    tex.colorSpace = THREE.SRGBColorSpace;
    return { canvas, tex };
  }, []);
  const bars = useMemo(() => Array.from({ length: 17 }, (_, i) => -0.9 + i * 0.1125), []);

  // cast/receive shadows on every mesh except the ones flagged noShadow
  useEffect(() => {
    root.current.traverse((o) => {
      if (o.isMesh && !o.userData.noShadow) {
        o.castShadow = true;
        o.receiveShadow = true;
      }
    });
  }, []);

  // keep the touchscreen in sync with the order
  const pct = Math.round(progress * 100);
  useEffect(() => {
    const paint = () => {
      drawScreen(screen.canvas, { phase, name, progress, token });
      screen.tex.needsUpdate = true;
    };
    paint();
    if (document.fonts?.ready) document.fonts.ready.then(paint);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [phase, name, token, pct, screen]);

  useEffect(() => {
    const c = phase === 'ready' ? '#7BE08A' : phase === 'idle' ? '#3E8F88' : '#F2A24B';
    dot.current.material.color.set(c);
  }, [phase]);

  useFrame(({ clock }, dt) => {
    const c = cur.current;
    const k = (rate) => 1 - Math.exp(-dt * rate);

    c.scale += (SIZE_SCALE[size] - c.scale) * k(6);

    let targetFill = 0;
    if (phase === 'brewing') targetFill = clamp((progress - 0.12) / 0.78, 0, 1);
    else if (phase === 'ready' || phase === 'collecting') targetFill = 1;
    if (phase === 'idle') c.fill = 0;
    else c.fill += (targetFill - c.fill) * k(10);

    // the cup lifts out toward the viewer when collected, then a fresh one glides back in
    const lifting = phase === 'collecting';
    target.set(0, lifting ? 1.0 : 0, lifting ? 1.9 : 0);
    c.off.lerp(target, k(lifting ? 5 : 4));
    cup.current.position.set(c.off.x, GRATE_Y + c.off.y, CUP_Z + c.off.z);
    cup.current.scale.setScalar(c.scale);

    const fillH = c.fill > 0.002 ? 0.05 + c.fill * (CUP_H - 0.2) : 0;
    liquid.current.visible = fillH > 0;
    liquid.current.scale.y = Math.max(fillH, 0.0001);
    liquid.current.position.y = 0.04 + fillH / 2;
    foam.current.visible = fillH > 0.06;
    foam.current.position.y = 0.04 + fillH;

    // the stream from nozzle to the surface of the chai
    const pouring = phase === 'brewing' && progress > 0.12 && progress < 0.93;
    c.stream += ((pouring ? 1 : 0) - c.stream) * k(16);
    const s = stream.current;
    s.visible = c.stream > 0.03;
    const surface = GRATE_Y + (0.04 + fillH) * c.scale;
    const h = Math.max(0.01, NOZZLE_Y - surface);
    const t = clock.elapsedTime;
    s.scale.set(c.stream * (1 + 0.12 * Math.sin(t * 38)), h, c.stream * (1 + 0.12 * Math.cos(t * 31)));
    s.position.set(0, surface + h / 2, CUP_Z);

    const pulse = phase === 'brewing' ? 1.4 + 0.5 * Math.sin(t * 5) : 1;
    ledMat.emissiveIntensity = 2.0 * pulse * (phase === 'ready' ? 1.25 : 1);
    light.current.intensity = 5 * pulse;
  });

  const cupTop = GRATE_Y + CUP_H * SIZE_SCALE[size];

  return (
    <group ref={root}>
      {/* drip tray housing */}
      <RoundedBox args={[W, 0.3, 1.9]} radius={0.05} smoothness={4} position={[0, 0.15, 0.1]}>
        <meshStandardMaterial color="#151413" metalness={0.5} roughness={0.45} />
      </RoundedBox>
      <mesh position={[0, 0.303, 0.25]} userData={NOSHADOW}>
        <boxGeometry args={[1.95, 0.006, 1.55]} />
        <meshStandardMaterial color="#050505" roughness={0.6} />
      </mesh>
      {bars.map((x) => (
        <mesh key={x} position={[x, 0.31, 0.25]}>
          <boxGeometry args={[0.035, 0.04, 1.5]} />
          <meshStandardMaterial color="#9A9DA0" metalness={0.9} roughness={0.3} />
        </mesh>
      ))}
      {[-0.35, 0.25, 0.85].map((z) => (
        <mesh key={z} position={[0, 0.305, z]}>
          <boxGeometry args={[1.9, 0.03, 0.035]} />
          <meshStandardMaterial color="#8A8D90" metalness={0.9} roughness={0.35} />
        </mesh>
      ))}
      <mesh position={[0, 0.28, 1.065]} material={copperMat}>
        <boxGeometry args={[W - 0.04, 0.03, 0.03]} />
      </mesh>

      {/* side walls, copper trim and the glowing LED edges of the opening */}
      {[-1, 1].map((sx) => (
        <group key={sx}>
          <RoundedBox args={[0.22, 1.7, 1.7]} radius={0.03} position={[sx * (W / 2 - 0.11), 1.15, 0]}>
            <meshStandardMaterial {...BODY} />
          </RoundedBox>
          <mesh position={[sx * (W / 2 - 0.045), 1.75, 0.875]} material={copperMat}>
            <boxGeometry args={[0.09, 2.9, 0.05]} />
          </mesh>
          <mesh position={[sx * 0.95, 1.15, 0.8]} material={ledMat} userData={NOSHADOW}>
            <boxGeometry args={[0.03, 1.55, 0.03]} />
          </mesh>
        </group>
      ))}

      {/* back wall of the cavity */}
      <RoundedBox args={[W - 0.44, 1.7, 0.14]} radius={0.02} position={[0, 1.15, -0.78]}>
        <meshStandardMaterial color="#0e0d0d" metalness={0.3} roughness={0.22} />
      </RoundedBox>

      {/* head of the machine */}
      <RoundedBox args={[W, 1.2, 1.7]} radius={0.08} smoothness={4} position={[0, 2.6, 0]}>
        <meshStandardMaterial {...BODY} />
      </RoundedBox>
      <mesh position={[0, 2.0, 0.875]} material={copperMat}>
        <boxGeometry args={[W, 0.03, 0.04]} />
      </mesh>
      <mesh position={[0, 1.96, 0.78]} material={ledMat} userData={NOSHADOW}>
        <boxGeometry args={[1.9, 0.04, 0.04]} />
      </mesh>
      <mesh position={[0, 1.985, 0.2]} userData={NOSHADOW}>
        <boxGeometry args={[1.5, 0.02, 0.9]} />
        <meshBasicMaterial color="#FFF3DC" toneMapped={false} />
      </mesh>
      <pointLight ref={light} position={[0, 1.8, 0.35]} color="#FFB45A" intensity={5} distance={4.5} decay={2} />

      {/* touchscreen */}
      <RoundedBox args={[1.14, 0.78, 0.04]} radius={0.03} position={[-0.3, 2.62, 0.86]}>
        <meshStandardMaterial color="#050505" metalness={0.4} roughness={0.2} />
      </RoundedBox>
      <mesh position={[-0.3, 2.62, 0.882]} userData={NOSHADOW}>
        <planeGeometry args={[1.0, 0.625]} />
        <meshBasicMaterial map={screen.tex} toneMapped={false} />
      </mesh>
      <mesh ref={dot} position={[0.7, 2.95, 0.87]} userData={NOSHADOW}>
        <sphereGeometry args={[0.035, 16, 16]} />
        <meshBasicMaterial color="#3E8F88" toneMapped={false} />
      </mesh>

      {/* nozzle */}
      <mesh position={[0, 1.89, CUP_Z]}>
        <boxGeometry args={[0.5, 0.2, 0.45]} />
        <meshStandardMaterial color="#C9CCCF" metalness={1} roughness={0.28} />
      </mesh>
      <mesh position={[0, 1.745, CUP_Z]}>
        <cylinderGeometry args={[0.055, 0.045, 0.09, 24]} />
        <meshStandardMaterial color="#B8BBBE" metalness={1} roughness={0.25} />
      </mesh>

      {/* the chai stream */}
      <mesh ref={stream} userData={NOSHADOW} visible={false}>
        <cylinderGeometry args={[0.026, 0.03, 1, 12]} />
        <meshStandardMaterial color={color} roughness={0.25} emissive={color} emissiveIntensity={0.25} />
      </mesh>

      {/* glass tumbler */}
      <group ref={cup} position={[0, GRATE_Y, CUP_Z]}>
        <mesh position={[0, CUP_H / 2, 0]} userData={NOSHADOW}>
          <cylinderGeometry args={[0.34, 0.3, CUP_H, 48, 1, true]} />
          <meshPhysicalMaterial
            color="#ffffff"
            transmission={1}
            thickness={0.12}
            roughness={0.04}
            ior={1.5}
            side={THREE.DoubleSide}
            envMapIntensity={1.2}
          />
        </mesh>
        <mesh position={[0, 0.02, 0]} userData={NOSHADOW}>
          <cylinderGeometry args={[0.3, 0.3, 0.05, 48]} />
          <meshPhysicalMaterial color="#ffffff" transmission={1} thickness={0.2} roughness={0.05} ior={1.5} />
        </mesh>
        <mesh ref={liquid} visible={false} userData={NOSHADOW}>
          <cylinderGeometry args={[0.298, 0.288, 1, 40]} />
          <meshPhysicalMaterial color={color} roughness={0.3} emissive={color} emissiveIntensity={0.18} clearcoat={0.4} />
        </mesh>
        <mesh ref={foam} visible={false} userData={NOSHADOW}>
          <cylinderGeometry args={[0.297, 0.297, 0.025, 40]} />
          <meshStandardMaterial color="#EBD3AE" roughness={0.9} />
        </mesh>
      </group>

      <Steam phase={phase} progress={progress} cupTop={cupTop} z={CUP_Z} />
    </group>
  );
}
