const SIZE_ORDER = ['small', 'regular', 'large'];

function Picker({ menu, sel, setSel, customerName, setCustomerName, user, busy, error, onOrder }) {
  const { products, sizes, sugarLevels } = menu;
  const product = products.find((p) => p.id === sel.productId);
  const price = product ? product.prices[sel.size] : 0;

  return (
    <form
      className="picker"
      onSubmit={(e) => {
        e.preventDefault();
        onOrder();
      }}
    >
      <fieldset className="field">
        <legend>Choose your chai</legend>
        <div className="chai-list">
          {products.map((p) => {
            const out = p.stock <= 0;
            const on = sel.productId === p.id;
            return (
              <label key={p.id} className={`chai${on ? ' is-on' : ''}${out ? ' is-out' : ''}`}>
                <input
                  type="radio"
                  name="chai"
                  value={p.id}
                  checked={on}
                  disabled={out}
                  onChange={() => setSel((s) => ({ ...s, productId: p.id }))}
                />
                <span className="swatch" style={{ background: p.color }} aria-hidden="true" />
                <span className="chai-text">
                  <span className="chai-name">{p.name}</span>
                  <span className="chai-notes">{p.notes}</span>
                </span>
                <span className="chai-side">
                  <span className="chai-price">₹{p.prices[sel.size]}</span>
                  {out && <span className="stock out">Sold out</span>}
                  {!out && p.stock <= 5 && <span className="stock low">{p.stock} left</span>}
                </span>
              </label>
            );
          })}
        </div>
      </fieldset>

      <fieldset className="field">
        <legend>Cup size</legend>
        <div className="seg seg-3">
          {SIZE_ORDER.filter((k) => sizes[k]).map((k) => (
            <label key={k} className={sel.size === k ? 'is-on' : ''}>
              <input type="radio" name="size" checked={sel.size === k} onChange={() => setSel((s) => ({ ...s, size: k }))} />
              <span>{sizes[k].label}</span>
              <small>{sizes[k].ml} ml</small>
            </label>
          ))}
        </div>
      </fieldset>

      <fieldset className="field">
        <legend>Sugar</legend>
        <div className="seg seg-4">
          {sugarLevels.map((label, i) => (
            <label key={label} className={sel.sugar === i ? 'is-on' : ''}>
              <input type="radio" name="sugar" checked={sel.sugar === i} onChange={() => setSel((s) => ({ ...s, sugar: i }))} />
              <span>{label}</span>
            </label>
          ))}
        </div>
      </fieldset>

      {!user && (
        <label className="text-field">
          <span>Name on the pickup screen (optional)</span>
          <input
            type="text"
            maxLength={24}
            value={customerName}
            onChange={(e) => setCustomerName(e.target.value)}
            autoComplete="given-name"
          />
        </label>
      )}

      {error && (
        <p className="error" role="alert">
          {error}
        </p>
      )}

      <button className="cta" type="submit" disabled={!product || busy}>
        {busy ? 'Starting the machine…' : `Pay ₹${price} and brew`}
      </button>
      <p className="fine">Demo checkout. No money is charged.</p>
    </form>
  );
}

function Brewing({ order, clock, menu, onCollect, collecting, error }) {
  const ready = clock.phase === 'ready';
  const p = clock.progress;
  const steps = [
    { label: 'Heating milk and tea', state: p >= 0.12 ? 'done' : 'now' },
    { label: 'Pouring', state: p >= 0.92 || ready ? 'done' : p >= 0.12 ? 'now' : 'wait' },
    { label: 'Finishing', state: ready ? 'done' : p >= 0.92 ? 'now' : 'wait' },
  ];
  const sizeLabel = menu.sizes[order.size]?.label.toLowerCase() || order.size;
  const sugarLabel = (menu.sugarLevels[order.sugar] || '').toLowerCase();

  if (collecting) {
    return (
      <div className="status" aria-live="polite">
        <h2>Enjoy your chai</h2>
        <p className="lead">Order {order.token} collected.</p>
      </div>
    );
  }

  return (
    <div className="status" aria-live="polite">
      <h2>{ready ? 'Your chai is ready' : `Brewing ${order.productName}`}</h2>
      <p className="lead">
        {order.productName}, {sizeLabel}, {sugarLabel}. ₹{order.price}.
      </p>

      {ready ? (
        <div className="pickup">
          <span className="pickup-label">Pickup code</span>
          <span className="pickup-code">{order.token}</span>
        </div>
      ) : (
        <>
          <div
            className="bar"
            role="progressbar"
            aria-label="Brewing progress"
            aria-valuemin={0}
            aria-valuemax={100}
            aria-valuenow={Math.round(p * 100)}
          >
            <span style={{ width: `${p * 100}%` }} />
          </div>
          <p className="remaining">{clock.remaining}s left</p>
          <ol className="steps">
            {steps.map((s) => (
              <li key={s.label} className={`step is-${s.state}`}>
                {s.label}
              </li>
            ))}
          </ol>
        </>
      )}

      {error && (
        <p className="error" role="alert">
          {error}
        </p>
      )}
      {ready && (
        <button className="cta" type="button" onClick={onCollect}>
          Take your chai
        </button>
      )}
    </div>
  );
}

export default function OrderPanel(props) {
  const { menu, loadError, onRetry, user, order, toast, onAuth, onSignOut, onOrders } = props;

  return (
    <aside className="panel">
      <header className="panel-head">
        <div className="brand">
          <span className="brand-mark" aria-hidden="true" />
          <h1>Tapri</h1>
        </div>
        <nav className="account" aria-label="Account">
          {user ? (
            <>
              <span className="who">{user.name}</span>
              <button type="button" className="link" onClick={onOrders}>
                My orders
              </button>
              <button type="button" className="link" onClick={onSignOut}>
                Sign out
              </button>
            </>
          ) : (
            <button type="button" className="link" onClick={onAuth}>
              Sign in
            </button>
          )}
        </nav>
      </header>

      <p className="tagline">Fresh chai, poured while you watch.</p>

      {loadError && (
        <div className="notice" role="alert">
          <p>{loadError}</p>
          <button type="button" className="link" onClick={onRetry}>
            Try again
          </button>
        </div>
      )}

      {!loadError && menu.products.length === 0 && <p className="fine">Loading the menu…</p>}

      {menu.products.length > 0 &&
        (order ? (
          <Brewing
            order={order}
            clock={props.clock}
            menu={menu}
            onCollect={props.onCollect}
            collecting={props.collecting}
            error={props.error}
          />
        ) : (
          <Picker {...props} />
        ))}

      <div className="toast" role="status" aria-live="polite">
        {toast}
      </div>
    </aside>
  );
}
