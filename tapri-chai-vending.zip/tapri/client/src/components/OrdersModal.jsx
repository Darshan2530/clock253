import { useEffect, useRef, useState } from 'react';
import { api } from '../api.js';

const fmt = new Intl.DateTimeFormat(undefined, { dateStyle: 'medium', timeStyle: 'short' });

export default function OrdersModal({ onClose }) {
  const [orders, setOrders] = useState(null);
  const [error, setError] = useState('');
  const closeRef = useRef(onClose);
  closeRef.current = onClose;

  useEffect(() => {
    api
      .myOrders()
      .then((d) => setOrders(d.orders))
      .catch((e) => setError(e.message));
    const onKey = (e) => e.key === 'Escape' && closeRef.current();
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  return (
    <div className="overlay" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div className="dialog" role="dialog" aria-modal="true" aria-labelledby="orders-title">
        <h2 id="orders-title">My orders</h2>
        {error && (
          <p className="error" role="alert">
            {error}
          </p>
        )}
        {!orders && !error && <p className="fine">Loading…</p>}
        {orders && orders.length === 0 && <p className="fine">No orders yet. Pick a chai and press brew.</p>}
        {orders && orders.length > 0 && (
          <ul className="history">
            {orders.map((o) => (
              <li key={o.id}>
                <span className="swatch" style={{ background: o.color }} aria-hidden="true" />
                <span className="history-main">
                  <strong>{o.productName}</strong>
                  <small>
                    {o.size}, {fmt.format(new Date(o.createdAt))}
                  </small>
                </span>
                <span className="history-side">
                  <strong>₹{o.price}</strong>
                  <small>{o.token}</small>
                </span>
              </li>
            ))}
          </ul>
        )}
        <div className="dialog-foot">
          <span />
          <button type="button" className="link" onClick={onClose}>
            Close
          </button>
        </div>
      </div>
    </div>
  );
}
