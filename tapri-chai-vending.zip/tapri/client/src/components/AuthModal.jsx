import { useEffect, useRef, useState } from 'react';
import { api, setToken } from '../api.js';

export default function AuthModal({ onClose, onDone }) {
  const [mode, setMode] = useState('login');
  const [form, setForm] = useState({ name: '', email: '', password: '' });
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const first = useRef(null);
  const closeRef = useRef(onClose);
  closeRef.current = onClose;

  // focus the first field when the dialog opens or the mode changes (not on every parent render)
  useEffect(() => {
    first.current?.focus();
  }, [mode]);

  useEffect(() => {
    const onKey = (e) => e.key === 'Escape' && closeRef.current();
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, []);

  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.value }));

  async function submit(e) {
    e.preventDefault();
    setError('');
    setBusy(true);
    try {
      const data = mode === 'login' ? await api.login(form) : await api.register(form);
      setToken(data.token);
      onDone(data.user);
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="overlay" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div className="dialog" role="dialog" aria-modal="true" aria-labelledby="auth-title">
        <h2 id="auth-title">{mode === 'login' ? 'Sign in' : 'Create an account'}</h2>
        <p className="fine">Accounts keep your order history. You can also order without one.</p>
        <form onSubmit={submit}>
          {mode === 'register' && (
            <label className="text-field">
              <span>Name</span>
              <input ref={first} required maxLength={40} value={form.name} onChange={set('name')} autoComplete="name" />
            </label>
          )}
          <label className="text-field">
            <span>Email</span>
            <input
              ref={mode === 'login' ? first : undefined}
              type="email"
              required
              value={form.email}
              onChange={set('email')}
              autoComplete="email"
            />
          </label>
          <label className="text-field">
            <span>Password</span>
            <input
              type="password"
              required
              minLength={mode === 'register' ? 8 : undefined}
              value={form.password}
              onChange={set('password')}
              autoComplete={mode === 'login' ? 'current-password' : 'new-password'}
            />
          </label>
          {error && (
            <p className="error" role="alert">
              {error}
            </p>
          )}
          <button className="cta" type="submit" disabled={busy}>
            {busy ? 'Please wait…' : mode === 'login' ? 'Sign in' : 'Create account'}
          </button>
        </form>
        <div className="dialog-foot">
          <button type="button" className="link" onClick={() => setMode(mode === 'login' ? 'register' : 'login')}>
            {mode === 'login' ? 'New here? Create an account' : 'Have an account? Sign in'}
          </button>
          <button type="button" className="link" onClick={onClose}>
            Close
          </button>
        </div>
      </div>
    </div>
  );
}
