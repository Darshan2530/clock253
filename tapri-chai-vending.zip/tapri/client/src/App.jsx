import { useCallback, useEffect, useState } from 'react';
import Scene from './scene/Scene.jsx';
import OrderPanel from './components/OrderPanel.jsx';
import AuthModal from './components/AuthModal.jsx';
import OrdersModal from './components/OrdersModal.jsx';
import { api, getToken, setToken, storage } from './api.js';
import { useOrderClock } from './useOrderClock.js';

const ACTIVE_KEY = 'tapri:activeOrder';
const withClock = (o) => ({ ...o, clockOffset: o.serverTime - Date.now() });

export default function App() {
  const [menu, setMenu] = useState({ products: [], sizes: {}, sugarLevels: [] });
  const [loadError, setLoadError] = useState('');
  const [sel, setSel] = useState({ productId: null, size: 'regular', sugar: 2 });
  const [customerName, setCustomerName] = useState('');
  const [user, setUser] = useState(null);
  const [order, setOrder] = useState(null);
  const [collecting, setCollecting] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [toast, setToast] = useState('');
  const [authOpen, setAuthOpen] = useState(false);
  const [ordersOpen, setOrdersOpen] = useState(false);
  const [view, setView] = useState({ name: 'overview', n: 0 });
  const clock = useOrderClock(order);

  const goTo = useCallback((name) => setView((v) => ({ name, n: v.n + 1 })), []);

  const loadMenu = useCallback(async () => {
    try {
      const data = await api.products();
      setMenu(data);
      setLoadError('');
      setSel((s) => {
        const stillOk = data.products.some((p) => p.id === s.productId && p.stock > 0);
        if (stillOk) return s;
        const first = data.products.find((p) => p.stock > 0) || data.products[0];
        return { ...s, productId: first ? first.id : null };
      });
    } catch (e) {
      setLoadError(e.message);
    }
  }, []);

  // first load: menu, signed-in user, and any cup that was still brewing when the tab closed
  useEffect(() => {
    loadMenu();
    if (getToken()) {
      api
        .me()
        .then((d) => setUser(d.user))
        .catch(() => setToken(null));
    }
    const activeId = storage.get(ACTIVE_KEY);
    if (activeId) {
      api
        .getOrder(activeId)
        .then((o) => {
          if (o.status === 'collected') return storage.del(ACTIVE_KEY);
          setOrder(withClock(o));
          setSel((s) => ({ ...s, productId: o.productId, size: o.size, sugar: o.sugar }));
          goTo('closeup');
          return undefined;
        })
        .catch(() => storage.del(ACTIVE_KEY));
    }
  }, [loadMenu, goTo]);

  useEffect(() => {
    if (!toast) return undefined;
    const id = setTimeout(() => setToast(''), 6000);
    return () => clearTimeout(id);
  }, [toast]);

  async function placeOrder() {
    setError('');
    setBusy(true);
    try {
      const o = await api.createOrder({
        productId: sel.productId,
        size: sel.size,
        sugar: sel.sugar,
        customerName: customerName.trim(),
      });
      storage.set(ACTIVE_KEY, o.id);
      setOrder(withClock(o));
      goTo('closeup');
      loadMenu();
    } catch (e) {
      const wait = e.data?.freeInSeconds;
      setError(wait ? `${e.message} Free in about ${wait}s.` : e.message);
      if (e.status === 409) loadMenu();
    } finally {
      setBusy(false);
    }
  }

  async function collect() {
    setError('');
    try {
      await api.collectOrder(order.id);
    } catch (e) {
      setError(e.message);
      return;
    }
    storage.del(ACTIVE_KEY);
    const token = order.token;
    setCollecting(true);
    setTimeout(() => {
      setCollecting(false);
      setOrder(null);
      goTo('overview');
      setToast(`Order ${token} collected. Enjoy your chai.`);
      loadMenu();
    }, 1300);
  }

  function signOut() {
    setToken(null);
    setUser(null);
    setOrdersOpen(false);
  }

  const product = menu.products.find((p) => p.id === sel.productId);
  const scenePhase = collecting ? 'collecting' : order ? clock.phase : 'idle';

  return (
    <div className="app">
      <div className="stage">
        <Scene
          products={menu.products}
          phase={scenePhase}
          progress={clock.progress}
          color={order ? order.color : product?.color || '#C28A55'}
          size={order ? order.size : sel.size}
          name={order?.productName || product?.name || ''}
          token={order?.token || ''}
          view={view.name}
          viewKey={view.n}
        />
        <p className="hint">Drag to look around. Scroll to zoom.</p>
        <div className="view-switch" role="group" aria-label="Camera view">
          <button type="button" aria-pressed={view.name === 'overview'} onClick={() => goTo('overview')}>
            Overview
          </button>
          <button type="button" aria-pressed={view.name === 'closeup'} onClick={() => goTo('closeup')}>
            Close-up
          </button>
        </div>
      </div>

      <OrderPanel
        menu={menu}
        loadError={loadError}
        onRetry={loadMenu}
        sel={sel}
        setSel={setSel}
        customerName={customerName}
        setCustomerName={setCustomerName}
        user={user}
        order={order}
        clock={clock}
        collecting={collecting}
        busy={busy}
        error={error}
        toast={toast}
        onOrder={placeOrder}
        onCollect={collect}
        onAuth={() => setAuthOpen(true)}
        onSignOut={signOut}
        onOrders={() => setOrdersOpen(true)}
      />

      {authOpen && (
        <AuthModal
          onClose={() => setAuthOpen(false)}
          onDone={(u) => {
            setUser(u);
            setAuthOpen(false);
          }}
        />
      )}
      {ordersOpen && <OrdersModal onClose={() => setOrdersOpen(false)} />}
    </div>
  );
}
