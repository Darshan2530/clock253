import { useEffect, useMemo, useState } from 'react';

/** Turns an order's server timestamps into live phase/progress for the animation and the panel. */
export function useOrderClock(order) {
  const [now, setNow] = useState(() => Date.now());

  useEffect(() => {
    if (!order) return undefined;
    const id = setInterval(() => setNow(Date.now()), 100);
    return () => clearInterval(id);
  }, [order]);

  return useMemo(() => {
    if (!order) return { phase: 'idle', progress: 0, remaining: 0 };
    const t = now + order.clockOffset;
    const start = new Date(order.createdAt).getTime();
    const end = new Date(order.readyAt).getTime();
    const progress = Math.min(1, Math.max(0, (t - start) / (end - start)));
    return {
      phase: t >= end ? 'ready' : 'brewing',
      progress,
      remaining: Math.max(0, Math.ceil((end - t) / 1000)),
    };
  }, [order, now]);
}
